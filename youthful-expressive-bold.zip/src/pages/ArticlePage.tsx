import React, { useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { ArrowLeft, Clock, Calendar, Share2, Instagram, Twitter, Music2 } from 'lucide-react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import ArticleCard from '@/components/ArticleCard';
import { ARTICLES } from '@/data/content';

const ArticlePage: React.FC = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const article = ARTICLES.find((a) => a.id === Number(id));

  useEffect(() => {
    window.scrollTo({ top: 0 });
  }, [id]);

  if (!article) {
    return (
      <div className="bg-white min-h-screen">
        <Navbar />
        <div className="pt-40 pb-32 text-center px-5">
          <h1 className="text-3xl font-extrabold text-[#1A1A1A] mb-4">Story not found</h1>
          <p className="text-gray-600 mb-8">This one might have been moved or deleted.</p>
          <Link to="/articles" className="inline-flex items-center gap-2 bg-[#6B46C1] text-white font-bold px-6 py-3 rounded-full">
            Back to all articles
          </Link>
        </div>
        <Footer />
      </div>
    );
  }

  const related = ARTICLES.filter((a) => a.id !== article.id && a.category === article.category).slice(0, 3);
  const fallback = ARTICLES.filter((a) => a.id !== article.id).slice(0, 3);
  const relatedList = related.length ? related : fallback;

  return (
    <div className="bg-white min-h-screen">
      <Navbar />

      {/* Hero cover */}
      <header className="relative pt-16 md:pt-20">
        <div className="relative h-[45vh] md:h-[60vh] overflow-hidden">
          <img src={article.cover} alt={article.title} className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#1A1A1A]/90 via-[#1A1A1A]/40 to-transparent" />
          <div className="absolute inset-x-0 bottom-0">
            <div className="max-w-3xl mx-auto px-5 sm:px-8 pb-10">
              <span className="inline-block bg-[#00D9C0] text-[#1A1A1A] text-[11px] font-bold uppercase tracking-widest px-3 py-1 rounded-full mb-4">
                {article.category}
              </span>
              <h1 className="text-white text-3xl sm:text-5xl font-extrabold leading-tight">{article.title}</h1>
            </div>
          </div>
        </div>
      </header>

      <article className="max-w-3xl mx-auto px-5 sm:px-8 py-10">
        <button onClick={() => navigate(-1)} className="flex items-center gap-1.5 text-[#6B46C1] font-bold text-sm mb-8 hover:gap-2.5 transition-all">
          <ArrowLeft size={16} /> Back
        </button>

        {/* Author + meta */}
        <div className="flex flex-wrap items-center justify-between gap-4 pb-8 border-b border-gray-100">
          <div className="flex items-center gap-3">
            <img src={article.authorAvatar} alt={article.author} className="w-12 h-12 rounded-full object-cover" />
            <div>
              <p className="font-bold text-[#1A1A1A]">{article.author}</p>
              <div className="flex items-center gap-4 text-xs text-gray-400 mt-0.5">
                <span className="flex items-center gap-1"><Calendar size={13} /> {article.date}</span>
                <span className="flex items-center gap-1"><Clock size={13} /> {article.readTime}</span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-sm text-gray-400 flex items-center gap-1"><Share2 size={14} /> Share</span>
            {[Instagram, Music2, Twitter].map((Icon, i) => (
              <a key={i} href="#" className="w-9 h-9 rounded-full bg-gray-100 flex items-center justify-center text-[#6B46C1] hover:bg-[#6B46C1] hover:text-white transition-colors">
                <Icon size={16} />
              </a>
            ))}
          </div>
        </div>

        {/* Body */}
        <div className="py-8 space-y-6">
          {article.body.map((p, i) => (
            <p key={i} className={`text-gray-800 leading-relaxed ${i === 0 ? 'text-xl font-medium' : 'text-lg'} ${i === article.body.length - 1 ? 'text-[#6B46C1] font-extrabold text-2xl' : ''}`}>
              {p}
            </p>
          ))}
        </div>

        {/* Author bio */}
        <div className="bg-gray-50 rounded-2xl p-6 flex gap-5 items-start mt-4">
          <img src={article.authorAvatar} alt={article.author} className="w-16 h-16 rounded-full object-cover shrink-0" />
          <div>
            <p className="text-xs font-bold uppercase tracking-widest text-[#00C4AD] mb-1">Written by</p>
            <h3 className="font-extrabold text-lg text-[#1A1A1A]">{article.author}</h3>
            <p className="text-gray-600 text-sm mt-1">{article.authorBio}</p>
          </div>
        </div>
      </article>

      {/* Related */}
      <section className="bg-gray-50 py-16">
        <div className="max-w-7xl mx-auto px-5 sm:px-8">
          <h2 className="text-2xl sm:text-3xl font-extrabold text-[#1A1A1A] mb-8">More stories like this</h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {relatedList.map((a) => <ArticleCard key={a.id} article={a} />)}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default ArticlePage;
