import React, { useState } from 'react';
import { Search } from 'lucide-react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import ArticleCard from '@/components/ArticleCard';
import { ARTICLES, CATEGORIES } from '@/data/content';

const Articles: React.FC = () => {
  const [active, setActive] = useState('All');
  const [query, setQuery] = useState('');

  const filtered = ARTICLES.filter((a) => {
    const catOk = active === 'All' || a.category === active;
    const q = query.toLowerCase();
    const qOk = !q || a.title.toLowerCase().includes(q) || a.excerpt.toLowerCase().includes(q) || a.author.toLowerCase().includes(q);
    return catOk && qOk;
  });

  return (
    <div className="bg-white min-h-screen">
      <Navbar />
      <header className="pt-32 pb-12 bg-gradient-to-br from-[#6B46C1] to-[#00D9C0]">
        <div className="max-w-7xl mx-auto px-5 sm:px-8">
          <p className="text-white/80 font-bold uppercase tracking-widest text-sm mb-3">Every voice, every story</p>
          <h1 className="text-white text-4xl sm:text-6xl font-extrabold">The Articles</h1>
          <p className="text-white/90 text-lg mt-4 max-w-2xl">Real takes from real teens. Pick a topic, dive in, and find the story that hits home.</p>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-5 sm:px-8 py-10">
        {/* Search */}
        <div className="relative max-w-md mb-6">
          <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search stories, authors, topics..."
            className="w-full pl-11 pr-4 py-3 rounded-full border border-gray-200 focus:outline-none focus:border-[#00D9C0]"
          />
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-2 mb-10">
          {['All', ...CATEGORIES].map((c) => (
            <button
              key={c}
              onClick={() => setActive(c)}
              className={`px-4 py-2 rounded-full text-sm font-bold transition-colors ${active === c ? 'bg-[#6B46C1] text-white' : 'bg-gray-100 text-[#1A1A1A] hover:bg-gray-200'}`}
            >
              {c}
            </button>
          ))}
        </div>

        {filtered.length === 0 ? (
          <p className="text-center text-gray-500 py-20 text-lg">No stories found. Try another search.</p>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {filtered.map((a) => <ArticleCard key={a.id} article={a} />)}
          </div>
        )}
      </div>
      <Footer />
    </div>
  );
};

export default Articles;
