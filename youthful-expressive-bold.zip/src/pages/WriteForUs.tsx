import React, { useState } from 'react';
import { Check, Lightbulb } from 'lucide-react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { COUNTRIES, CATEGORIES } from '@/data/content';

const guidelines = [
  'Write about something you actually care about — passion beats perfect grammar every time.',
  'Keep it real. We want your honest voice, not what you think adults want to hear.',
  'Pitches should be 100–500 words. Tell us your angle and why it matters now.',
  "You must be 13–19. That's the whole crew, no exceptions.",
];

const WriteForUs: React.FC = () => {
  const [form, setForm] = useState({ name: '', age: '', country: '', category: '', title: '', pitch: '', email: '' });
  const [sent, setSent] = useState(false);

  const update = (k: string, v: string) => setForm({ ...form, [k]: v });

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (form.email) {
      try {
        await fetch('https://famous.ai/api/crm/6a234d2773723ba889d7b2a8/subscribe', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email: form.email, name: form.name, source: 'write-for-us', tags: ['writer', 'pitch'] }),
        });
      } catch (e) { /* noop */ }
    }
    setSent(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="bg-white min-h-screen">
      <Navbar />
      <header className="pt-32 pb-12 bg-gradient-to-br from-[#6B46C1] to-[#00D9C0]">
        <div className="max-w-7xl mx-auto px-5 sm:px-8">
          <p className="text-white/80 font-bold uppercase tracking-widest text-sm mb-3">Your byline awaits</p>
          <h1 className="text-white text-4xl sm:text-6xl font-extrabold">Write for Us</h1>
        </div>
      </header>

      <div className="max-w-5xl mx-auto px-5 sm:px-8 py-16 grid lg:grid-cols-5 gap-12">
        <div className="lg:col-span-2">
          <p className="text-gray-700 text-lg leading-relaxed mb-8">
            Got a story burning a hole in your brain? Pitch it. We publish teens from everywhere, and we read every single submission. No experience needed — just something to say and the guts to say it.
          </p>
          <div className="bg-gray-50 rounded-2xl p-6">
            <div className="flex items-center gap-2 mb-4">
              <Lightbulb className="text-[#00C4AD]" size={20} />
              <h3 className="font-extrabold text-[#1A1A1A]">Submission Guidelines</h3>
            </div>
            <ul className="space-y-3">
              {guidelines.map((g, i) => (
                <li key={i} className="flex gap-3 text-gray-700 text-sm">
                  <Check size={18} className="text-[#6B46C1] shrink-0 mt-0.5" />
                  <span>{g}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="lg:col-span-3">
          {sent ? (
            <div className="bg-[#00D9C0]/10 border-2 border-[#00D9C0] rounded-2xl p-10 text-center">
              <div className="w-16 h-16 bg-[#00D9C0] rounded-full flex items-center justify-center mx-auto mb-4">
                <Check className="text-white" size={32} />
              </div>
              <h3 className="text-2xl font-extrabold text-[#1A1A1A] mb-2">Pitch received!</h3>
              <p className="text-gray-600">Nice. An editor will read your pitch and get back to you within a week. Keep an eye on your inbox.</p>
              <button onClick={() => { setSent(false); setForm({ name: '', age: '', country: '', category: '', title: '', pitch: '', email: '' }); }} className="mt-6 bg-[#6B46C1] text-white font-bold px-6 py-3 rounded-full hover:bg-[#5a37a8]">
                Submit another
              </button>
            </div>
          ) : (
            <form onSubmit={submit} className="space-y-5">
              <div className="grid sm:grid-cols-2 gap-5">
                <Field label="Your name" value={form.name} onChange={(v) => update('name', v)} required />
                <Field label="Email" type="email" value={form.email} onChange={(v) => update('email', v)} required />
              </div>
              <div className="grid sm:grid-cols-2 gap-5">
                <Field label="Age" type="number" value={form.age} onChange={(v) => update('age', v)} required />
                <div>
                  <Label>Country</Label>
                  <select required value={form.country} onChange={(e) => update('country', e.target.value)} className={selectCls}>
                    <option value="">Select...</option>
                    {COUNTRIES.map((c) => <option key={c}>{c}</option>)}
                  </select>
                </div>
              </div>
              <div>
                <Label>Article category</Label>
                <select required value={form.category} onChange={(e) => update('category', e.target.value)} className={selectCls}>
                  <option value="">Pick a topic...</option>
                  {CATEGORIES.map((c) => <option key={c}>{c}</option>)}
                </select>
              </div>
              <Field label="Pitch title" value={form.title} onChange={(v) => update('title', v)} required />
              <div>
                <Label>Your pitch <span className="text-gray-400 font-normal">({form.pitch.length}/500)</span></Label>
                <textarea
                  required
                  maxLength={500}
                  rows={6}
                  value={form.pitch}
                  onChange={(e) => update('pitch', e.target.value)}
                  placeholder="Tell us your angle. What's the story, why does it matter, and why are you the one to write it?"
                  className={`${inputCls} resize-none`}
                />
              </div>
              <button type="submit" className="w-full bg-[#6B46C1] text-white font-bold text-lg py-4 rounded-full hover:bg-[#5a37a8] transition-colors">
                Send my pitch
              </button>
            </form>
          )}
        </div>
      </div>
      <Footer />
    </div>
  );
};

const inputCls = 'w-full border border-gray-200 rounded-xl px-4 py-3 focus:outline-none focus:border-[#00D9C0] focus:ring-1 focus:ring-[#00D9C0]';
const selectCls = inputCls + ' bg-white';
const Label: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <label className="block text-sm font-bold text-[#1A1A1A] mb-1.5">{children}</label>
);
const Field: React.FC<{ label: string; value: string; onChange: (v: string) => void; type?: string; required?: boolean }> = ({ label, value, onChange, type = 'text', required }) => (
  <div>
    <Label>{label}</Label>
    <input type={type} required={required} value={value} onChange={(e) => onChange(e.target.value)} className={inputCls} />
  </div>
);

export default WriteForUs;
