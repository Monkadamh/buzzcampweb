import React, { useState } from 'react';
import { Check, Clock, Instagram, Twitter, Music2, Mail } from 'lucide-react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';

const Contact: React.FC = () => {
  const [form, setForm] = useState({ name: '', email: '', message: '' });
  const [sent, setSent] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await fetch('https://famous.ai/api/crm/6a234d2773723ba889d7b2a8/subscribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: form.email, name: form.name, source: 'contact-form', tags: ['contact'] }),
      });
    } catch (e) { /* noop */ }
    setSent(true);
  };

  return (
    <div className="bg-white min-h-screen">
      <Navbar />
      <header className="pt-32 pb-12 bg-gradient-to-br from-[#6B46C1] to-[#00D9C0]">
        <div className="max-w-7xl mx-auto px-5 sm:px-8">
          <p className="text-white/80 font-bold uppercase tracking-widest text-sm mb-3">Say hey</p>
          <h1 className="text-white text-4xl sm:text-6xl font-extrabold">Get in Touch</h1>
        </div>
      </header>

      <div className="max-w-5xl mx-auto px-5 sm:px-8 py-16 grid lg:grid-cols-2 gap-12">
        <div>
          <h2 className="text-3xl font-extrabold text-[#1A1A1A] mb-4">Drop us a line</h2>
          <p className="text-gray-700 text-lg mb-6">Questions, ideas, collabs, or just want to tell us your story didn't get picked? We're listening. Seriously.</p>
          <div className="flex items-center gap-2 bg-[#00D9C0]/10 text-[#1A1A1A] rounded-xl px-4 py-3 mb-8 font-semibold">
            <Clock size={18} className="text-[#00C4AD]" /> We usually respond within 48 hours.
          </div>
          <div className="flex items-center gap-2 text-gray-700 mb-6">
            <Mail size={18} className="text-[#6B46C1]" /> hello@buzzcampus.com
          </div>
          <p className="font-bold text-[#1A1A1A] mb-3">Find us online</p>
          <div className="flex gap-3">
            {[Instagram, Music2, Twitter].map((Icon, i) => (
              <a key={i} href="#" className="w-12 h-12 rounded-full bg-[#6B46C1] text-white flex items-center justify-center hover:bg-[#00C4AD] transition-colors">
                <Icon size={20} />
              </a>
            ))}
          </div>
        </div>

        <div>
          {sent ? (
            <div className="bg-[#00D9C0]/10 border-2 border-[#00D9C0] rounded-2xl p-10 text-center">
              <div className="w-16 h-16 bg-[#00D9C0] rounded-full flex items-center justify-center mx-auto mb-4">
                <Check className="text-white" size={32} />
              </div>
              <h3 className="text-2xl font-extrabold text-[#1A1A1A] mb-2">Message sent!</h3>
              <p className="text-gray-600">Thanks for reaching out. We'll get back to you within 48 hours.</p>
            </div>
          ) : (
            <form onSubmit={submit} className="space-y-5">
              <div>
                <label className="block text-sm font-bold text-[#1A1A1A] mb-1.5">Name</label>
                <input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className={inputCls} />
              </div>
              <div>
                <label className="block text-sm font-bold text-[#1A1A1A] mb-1.5">Email</label>
                <input type="email" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className={inputCls} />
              </div>
              <div>
                <label className="block text-sm font-bold text-[#1A1A1A] mb-1.5">Message</label>
                <textarea required rows={6} value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} className={`${inputCls} resize-none`} />
              </div>
              <button type="submit" className="w-full bg-[#6B46C1] text-white font-bold text-lg py-4 rounded-full hover:bg-[#5a37a8] transition-colors">
                Send message
              </button>
            </form>
          )}
        </div>
      </div>
      <Footer />
    </div>
  );
};

const inputCls = 'w-full border border-gray-200 rounded-xl px-4 py-3 focus:outline-none focus:border-[#00D9C0] focus:ring-1 focus:ring-[#00D9C0]';

export default Contact;
