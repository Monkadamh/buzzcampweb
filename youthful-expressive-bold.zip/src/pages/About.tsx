import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { TEAM } from '@/data/content';

const About: React.FC = () => {
  return (
    <div className="bg-white min-h-screen">
      <Navbar />
      <header className="pt-32 pb-12 bg-gradient-to-br from-[#6B46C1] to-[#00D9C0]">
        <div className="max-w-7xl mx-auto px-5 sm:px-8">
          <p className="text-white/80 font-bold uppercase tracking-widest text-sm mb-3">Who we are</p>
          <h1 className="text-white text-4xl sm:text-6xl font-extrabold">Founded by teens, for teens.</h1>
        </div>
      </header>

      {/* Story */}
      <section className="max-w-3xl mx-auto px-5 sm:px-8 py-16">
        <h2 className="text-3xl font-extrabold text-[#1A1A1A] mb-6">Our Story</h2>
        <div className="space-y-5 text-gray-700 text-lg leading-relaxed">
          <p>BuzzCampus started in a group chat. A few of us were tired of reading about teens instead of hearing from them. Every article about "kids these days" was written by someone who hadn't been a teenager in decades. So we decided to do it ourselves.</p>
          <p>What began as a shared Google Doc turned into a global magazine. Today, BuzzCampus is run entirely by teenagers — editors, writers, designers, and organizers — all under 19. We're spread across more than 60 countries and united by one belief: our voices matter now, not "someday."</p>
          <p>We cover the stuff that actually fills our days and keeps us up at night: identity, school, mental health, climate, culture, and activism. No watered-down takes. No adults rewriting our words to sound more "appropriate."</p>
          <p>This is a place where a 14-year-old from Lagos and a 17-year-old from Seoul can publish side by side, and where every pitch gets read by someone who genuinely gets it. We're not waiting for permission to be heard. We're building the platform ourselves.</p>
        </div>
      </section>

      {/* Stats */}
      <section className="bg-gray-50 py-16">
        <div className="max-w-5xl mx-auto px-5 sm:px-8 grid grid-cols-1 sm:grid-cols-3 gap-8 text-center">
          {[['1,200+', 'Articles published'], ['60+', 'Countries represented'], ['600+', 'Teen writers']].map(([n, l]) => (
            <div key={l}>
              <div className="text-5xl font-extrabold text-[#6B46C1]">{n}</div>
              <div className="text-gray-600 mt-2 font-semibold">{l}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Team */}
      <section className="max-w-7xl mx-auto px-5 sm:px-8 py-16">
        <p className="text-[#00C4AD] font-bold uppercase tracking-widest text-sm mb-2 text-center">The crew</p>
        <h2 className="text-3xl sm:text-4xl font-extrabold text-[#1A1A1A] mb-12 text-center">Meet the Team</h2>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
          {TEAM.map((m) => (
            <div key={m.id} className="group text-center">
              <div className="relative overflow-hidden rounded-2xl mb-4">
                <img src={m.photo} alt={m.name} className="w-full aspect-square object-cover group-hover:scale-105 transition-transform duration-500" />
                <div className="absolute inset-0 bg-gradient-to-t from-[#6B46C1]/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
              <h3 className="font-extrabold text-[#1A1A1A] text-lg">{m.name}</h3>
              <p className="text-[#00C4AD] font-semibold text-sm mb-2">{m.role}</p>
              <p className="text-gray-500 text-sm">{m.bio}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="py-20 bg-gradient-to-r from-[#6B46C1] to-[#00D9C0] text-center">
        <div className="max-w-3xl mx-auto px-5 sm:px-8">
          <h2 className="text-white text-3xl sm:text-5xl font-extrabold">Want to be part of it?</h2>
          <Link to="/write" className="inline-flex items-center gap-2 bg-white text-[#6B46C1] font-bold text-lg px-8 py-4 rounded-full mt-8 hover:scale-105 transition-transform">
            Write for Us <ArrowRight size={20} />
          </Link>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default About;
