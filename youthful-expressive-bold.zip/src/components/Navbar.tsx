import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X } from 'lucide-react';

const links = [
  { to: '/', label: 'Home' },
  { to: '/articles', label: 'Articles' },
  { to: '/about', label: 'About' },
  { to: '/write', label: 'Write for Us' },
  { to: '/contact', label: 'Contact' },
];

const Navbar: React.FC = () => {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 10);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => setOpen(false), [location.pathname]);

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? 'bg-white/95 backdrop-blur shadow-md' : 'bg-white'}`}>
      <div className="max-w-7xl mx-auto px-5 sm:px-8 h-16 md:h-20 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-1 group">
          <span className="text-2xl md:text-3xl font-extrabold tracking-tight text-[#1A1A1A]">Buzz</span>
          <span className="text-2xl md:text-3xl font-extrabold tracking-tight text-[#00C4AD]">Campus</span>
          <span className="ml-1 w-2 h-2 rounded-full bg-[#6B46C1] group-hover:scale-150 transition-transform" />
        </Link>

        <div className="hidden md:flex items-center gap-8">
          {links.map((l) => {
            const active = location.pathname === l.to;
            return (
              <Link
                key={l.to}
                to={l.to}
                className={`relative text-sm font-semibold transition-colors ${active ? 'text-[#6B46C1]' : 'text-[#1A1A1A] hover:text-[#00C4AD]'} group`}
              >
                {l.label}
                <span className={`absolute -bottom-1 left-0 h-0.5 bg-[#00C4AD] transition-all duration-300 ${active ? 'w-full' : 'w-0 group-hover:w-full'}`} />
              </Link>
            );
          })}
          <Link to="/write" className="bg-[#6B46C1] text-white text-sm font-bold px-5 py-2.5 rounded-full hover:bg-[#5a37a8] transition-colors">
            Pitch a Story
          </Link>
        </div>

        <button className="md:hidden text-[#1A1A1A]" onClick={() => setOpen(!open)} aria-label="Menu">
          {open ? <X size={28} /> : <Menu size={28} />}
        </button>
      </div>

      {open && (
        <div className="md:hidden bg-white border-t border-gray-100 px-5 py-4 space-y-1 shadow-lg">
          {links.map((l) => (
            <Link
              key={l.to}
              to={l.to}
              className={`block py-3 text-lg font-semibold ${location.pathname === l.to ? 'text-[#6B46C1]' : 'text-[#1A1A1A]'}`}
            >
              {l.label}
            </Link>
          ))}
          <Link to="/write" className="block text-center bg-[#6B46C1] text-white font-bold px-5 py-3 rounded-full mt-3">
            Pitch a Story
          </Link>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
