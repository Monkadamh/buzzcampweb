import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, PenLine, Sparkles } from 'lucide-react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import ArticleCard from '@/components/ArticleCard';
import { ARTICLES } from '@/data/content';

const hero = 'https://d64gsuwffb70l.cloudfront.net/6a234d2773723ba889d7b2a8_1780698497352_bb8ebee1.jpg';

const AppLayout: React.FC = () => {
  const featured = ARTICLES.filter((a) => a.featured);
  const latest = ARTICLES.slice(3, 12);

  return (
    <div className="bg-white">
      <Navbar />

      {/* HERO */}
      <section className="relative min-h-screen flex items-center overflow-hidden">
        <img src={hero} alt="" className="absolute inset-0 w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-br from-[#6B46C1]/95 via-[#6B46C1]/85 to-[#00D9C0]/80" />
        <div className="relative max-w-7xl mx-auto px-5 sm:px-8 py-32 w-full">
          <div className="inline-flex items-center gap-2 bg-white/15 backdrop-blur text-white text-xs font-bold uppercase tracking-widest px-4 py-2 rounded-full mb-6">
            <Sparkles size={14} /> The teen magazine that talks back
          </div>
          <h1 className="text-white font-extrabold leading-[0.95] tracking-tight text-[3.25rem] sm:text-7xl lg:text-8xl max-w-5xl">
            We don't wait <br />
            <span className="text-[#00D9C0]">to be heard.</span>
          </h1>
          <p className="text-white/90 text-lg sm:text-xl max-w-2xl mt-8 leading-relaxed">
            BuzzCampus is a digital magazine empowering teens around the world to share their voices — through articles, opinions, and the stories nobody else will print. This is your space.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 mt-10">
            <Link to="/articles" className="bg-[#00D9C0] text-[#1A1A1A] font-bold text-lg px-8 py-4 rounded-full hover:bg-white transition-colors flex items-center justify-center gap-2">
              Read the Latest <ArrowRight size={20} />
            </Link>
            <Link to="/write" className="bg-white/10 border-2 border-white text-white font-bold text-lg px-8 py-4 rounded-full hover:bg-white hover:text-[#6B46C1] transition-colors flex items-center justify-center gap-2">
              <PenLine size={20} /> Write for Us
            </Link>
          </div>
          <div className="flex flex-wrap gap-8 mt-16 text-white">
            {[['1,200+', 'Stories published'], ['60+', 'Countries'], ['600+', 'Teen writers']].map(([n, l]) => (
              <div key={l}>
                <div className="text-3xl sm:text-4xl font-extrabold text-[#00D9C0]">{n}</div>
                <div className="text-sm text-white/80">{l}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* MISSION */}
      <section className="py-20 bg-white">
        <div className="max-w-4xl mx-auto px-5 sm:px-8 text-center">
          <p className="text-[#00C4AD] font-bold uppercase tracking-widest text-sm mb-4">Our Mission</p>
          <h2 className="text-3xl sm:text-5xl font-extrabold text-[#1A1A1A] leading-tight">
            Adults have had the mic long enough. <span className="text-[#6B46C1]">It's our turn.</span>
          </h2>
          <p className="text-gray-600 text-lg sm:text-xl mt-6 leading-relaxed">
            We give teens a real platform to write about the things that actually matter to us — identity, school, climate, mental health, culture, and everything in between. No filters. No gatekeepers.
          </p>
        </div>
      </section>

      {/* FEATURED */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-5 sm:px-8">
          <div className="flex items-end justify-between mb-10">
            <div>
              <p className="text-[#00C4AD] font-bold uppercase tracking-widest text-sm mb-2">Featured</p>
              <h2 className="text-3xl sm:text-4xl font-extrabold text-[#1A1A1A]">Stories you need to read</h2>
            </div>
            <Link to="/articles" className="hidden sm:flex items-center gap-1 text-[#6B46C1] font-bold hover:gap-2 transition-all">
              View all <ArrowRight size={18} />
            </Link>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {featured.map((a) => <ArticleCard key={a.id} article={a} large />)}
          </div>
        </div>
      </section>

      {/* LATEST */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-5 sm:px-8">
          <div className="mb-10">
            <p className="text-[#00C4AD] font-bold uppercase tracking-widest text-sm mb-2">Fresh off the keyboard</p>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-[#1A1A1A]">Latest Voices</h2>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {latest.map((a) => <ArticleCard key={a.id} article={a} />)}
          </div>
        </div>
      </section>

      {/* JOIN CTA */}
      <section className="py-24 bg-gradient-to-r from-[#6B46C1] to-[#00D9C0]">
        <div className="max-w-4xl mx-auto px-5 sm:px-8 text-center">
          <h2 className="text-white text-4xl sm:text-6xl font-extrabold leading-tight">Got something to say?</h2>
          <p className="text-white/90 text-lg sm:text-xl mt-5 max-w-2xl mx-auto">
            Join the movement. Pitch your story, share your opinion, and reach thousands of teens who get it.
          </p>
          <Link to="/write" className="inline-flex items-center gap-2 bg-white text-[#6B46C1] font-bold text-lg px-8 py-4 rounded-full mt-8 hover:scale-105 transition-transform">
            Join the Movement <ArrowRight size={20} />
          </Link>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default AppLayout;
