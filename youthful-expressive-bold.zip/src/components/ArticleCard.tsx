import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { Article } from '@/data/content';

const ArticleCard: React.FC<{ article: Article; large?: boolean }> = ({ article, large }) => {
  return (
    <article className="group bg-white rounded-2xl overflow-hidden border border-gray-100 hover:border-[#00D9C0] hover:shadow-xl hover:-translate-y-1 transition-all duration-300 flex flex-col">
      <Link to={`/article/${article.id}`} className="relative overflow-hidden block">
        <img
          src={article.cover}
          alt={article.title}
          className={`w-full object-cover group-hover:scale-105 transition-transform duration-500 ${large ? 'h-56' : 'h-48'}`}
        />
        <span className="absolute top-4 left-4 bg-white/95 backdrop-blur text-[#6B46C1] text-[11px] font-bold uppercase tracking-widest px-3 py-1 rounded-full">
          {article.category}
        </span>
      </Link>
      <div className="p-6 flex flex-col flex-1">
        <Link to={`/article/${article.id}`}>
          <h3 className={`font-extrabold text-[#1A1A1A] leading-tight mb-3 group-hover:text-[#6B46C1] transition-colors ${large ? 'text-2xl' : 'text-xl'}`}>
            {article.title}
          </h3>
        </Link>
        <p className="text-gray-600 text-[15px] mb-5 flex-1">{article.excerpt}</p>
        <div className="flex items-center justify-between mt-auto">
          <div className="flex items-center gap-2.5">
            <img src={article.authorAvatar} alt={article.author} className="w-8 h-8 rounded-full object-cover" />
            <div className="leading-tight">
              <p className="text-sm font-semibold text-[#1A1A1A]">{article.author}</p>
              <p className="text-xs text-gray-400">{article.date}</p>
            </div>
          </div>
          <Link to={`/article/${article.id}`} className="text-[#00C4AD] flex items-center gap-1 text-sm font-bold group-hover:gap-2 transition-all">
            Read <ArrowRight size={15} />
          </Link>
        </div>
      </div>
    </article>
  );
};

export default ArticleCard;
