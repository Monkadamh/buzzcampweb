import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Instagram, Twitter, Music2 } from 'lucide-react';

const Footer: React.FC = () => {
  const [email, setEmail] = useState('');
  const [done, setDone] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    try {
      await fetch('https://famous.ai/api/crm/6a234d2773723ba889d7b2a8/subscribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, source: 'footer-signup', tags: ['newsletter'] }),
      });
    } catch (e) { /* noop */ }
    setDone(true);
    setEmail('');
  };

  return (
    <footer className="bg-[#1A1A1A] text-white">
      <div className="max-w-7xl mx-auto px-5 sm:px-8 py-16">
        <div className="grid md:grid-cols-4 gap-10">
          <div className="md:col-span-2">
            <div className="flex items-center gap-1 mb-4">
              <span className="text-2xl font-extrabold">Buzz</span>
              <span className="text-2xl font-extrabold text-[#00D9C0]">Campus</span>
            </div>
            <p className="text-gray-400 max-w-sm mb-6 text-lg">We don't wait to be heard. A digital magazine built by teens, for teens, all around the world.</p>
            <form onSubmit={submit} className="flex gap-2 max-w-sm">
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Your email"
                className="flex-1 bg-white/10 border border-white/20 rounded-full px-4 py-2.5 text-sm focus:outline-none focus:border-[#00D9C0]"
              />
              <button type="submit" className="bg-[#00D9C0] text-[#1A1A1A] font-bold px-5 py-2.5 rounded-full text-sm hover:bg-[#00c4ad]">
                Join
              </button>
            </form>
            {done && <p className="text-[#00D9C0] text-sm mt-2">You're in. Welcome to the movement.</p>}
          </div>

          <div>
            <h4 className="font-bold mb-4 uppercase text-xs tracking-widest text-gray-500">Explore</h4>
            <ul className="space-y-3 text-gray-300">
              <li><Link to="/articles" className="hover:text-[#00D9C0]">Articles</Link></li>
              <li><Link to="/about" className="hover:text-[#00D9C0]">About Us</Link></li>
              <li><Link to="/write" className="hover:text-[#00D9C0]">Write for Us</Link></li>
              <li><Link to="/contact" className="hover:text-[#00D9C0]">Contact</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold mb-4 uppercase text-xs tracking-widest text-gray-500">Follow</h4>
            <div className="flex gap-3">
              {[Instagram, Music2, Twitter].map((Icon, i) => (
                <a key={i} href="#" className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-[#00D9C0] hover:text-[#1A1A1A] transition-colors">
                  <Icon size={18} />
                </a>
              ))}
            </div>
          </div>
        </div>

        <div className="border-t border-white/10 mt-12 pt-6 text-sm text-gray-500 flex flex-col sm:flex-row justify-between gap-2">
          <p>&copy; 2026 BuzzCampus. Made by teens who refuse to be quiet.</p>
          <p>Privacy · Terms</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
