export interface Article {
  id: number;
  title: string;
  author: string;
  authorAvatar: string;
  authorBio: string;
  category: string;
  excerpt: string;
  body: string[];
  cover: string;
  date: string;
  readTime: string;
  featured?: boolean;
}

export interface TeamMember {
  id: number;
  name: string;
  role: string;
  bio: string;
  photo: string;
}

const covers = [
  'https://d64gsuwffb70l.cloudfront.net/6a234d2773723ba889d7b2a8_1780698516416_d8b77e65.jpg',
  'https://d64gsuwffb70l.cloudfront.net/6a234d2773723ba889d7b2a8_1780698518285_a0277127.jpg',
  'https://d64gsuwffb70l.cloudfront.net/6a234d2773723ba889d7b2a8_1780698519175_7dfde2d5.jpg',
  'https://d64gsuwffb70l.cloudfront.net/6a234d2773723ba889d7b2a8_1780698523808_bff12b42.png',
  'https://d64gsuwffb70l.cloudfront.net/6a234d2773723ba889d7b2a8_1780698525330_e415f2f1.png',
  'https://d64gsuwffb70l.cloudfront.net/6a234d2773723ba889d7b2a8_1780698523040_ae49ff04.png',
  'https://d64gsuwffb70l.cloudfront.net/6a234d2773723ba889d7b2a8_1780698522884_67c0db71.jpg',
  'https://d64gsuwffb70l.cloudfront.net/6a234d2773723ba889d7b2a8_1780698528375_49952b2a.png',
  'https://d64gsuwffb70l.cloudfront.net/6a234d2773723ba889d7b2a8_1780698526799_2aa88e8b.png',
];

const avatars = [
  'https://d64gsuwffb70l.cloudfront.net/6a234d2773723ba889d7b2a8_1780698549392_9a344920.png',
  'https://d64gsuwffb70l.cloudfront.net/6a234d2773723ba889d7b2a8_1780698545152_fe8dc66f.jpg',
  'https://d64gsuwffb70l.cloudfront.net/6a234d2773723ba889d7b2a8_1780698548091_051c7e60.png',
  'https://d64gsuwffb70l.cloudfront.net/6a234d2773723ba889d7b2a8_1780698546685_260f1768.jpg',
  'https://d64gsuwffb70l.cloudfront.net/6a234d2773723ba889d7b2a8_1780698558007_97c42b1a.png',
  'https://d64gsuwffb70l.cloudfront.net/6a234d2773723ba889d7b2a8_1780698550741_d1bf89f5.jpg',
  'https://d64gsuwffb70l.cloudfront.net/6a234d2773723ba889d7b2a8_1780698555642_d537b27f.png',
  'https://d64gsuwffb70l.cloudfront.net/6a234d2773723ba889d7b2a8_1780698551890_570dd33e.jpg',
];

export const CATEGORIES = ['Opinion', 'Culture', 'Identity', 'School', 'Climate', 'Mental Health', 'Tech', 'Activism'];

const titles = [
  ['Why nobody asked Gen Z before deciding our future', 'Opinion', 'Spoiler: we have a lot to say, and we are done waiting for permission to say it.'],
  ['The group chat saved my mental health', 'Mental Health', 'On the friends who showed up at 2am when the adults in the room had no clue.'],
  ['I quit being the "perfect student" and finally started living', 'School', 'Burnout at 16 is real. Here is how I stopped chasing a grade and found myself.'],
  ['My culture is not your aesthetic', 'Culture', 'A love letter to the traditions that made me, and a warning to the people stealing them.'],
  ['Coming out to my parents over text — and zero regrets', 'Identity', 'Sometimes the bravest thing you can do is hit send.'],
  ['We are the climate generation whether you like it or not', 'Climate', 'Why I skip class to protest, and why my teachers secretly agree with me.'],
  ['TikTok taught me more than my economics teacher', 'Tech', 'An honest look at where teens actually learn — and why school needs to catch up.'],
  ['Walkouts, petitions, and the power of a 15-year-old', 'Activism', 'How a group of bored students changed an entire district policy.'],
  ['The pressure to have it all figured out is a lie', 'Opinion', 'You do not need a five-year plan at fifteen. Trust me on this one.'],
  ['Finding my people in a town that never understood me', 'Identity', 'Small town, big feelings, and the internet that became my real home.'],
  ['Why I deleted social media for 30 days', 'Mental Health', 'It was awful, then it was amazing. Here is everything I learned.'],
  ['Our school dress code is sexist and we proved it', 'School', 'We collected the receipts. The administration was not ready.'],
  ['Music is the only language that gets me', 'Culture', 'On the playlists that carried me through the hardest year of my life.'],
  ['I am not too young to care about politics', 'Activism', 'We cannot vote yet, but our voices are already shaping the conversation.'],
  ['The truth about being the new kid every single year', 'Identity', 'Moving cities five times taught me how to belong anywhere.'],
  ['Climate anxiety is not a phase, it is a wake-up call', 'Climate', 'How I turned my fear about the planet into something that actually helps.'],
  ['AI did my homework and I still feel weird about it', 'Tech', 'Where is the line? A teen tries to figure out the ethics of the future.'],
  ['Why representation in books actually changed my life', 'Culture', 'The first time I saw myself in a story, everything shifted.'],
  ['Standing up to a bully taught me who I really am', 'Opinion', 'It was terrifying. It was worth it. Here is what happened next.'],
  ['The art class that saved me from giving up', 'Mental Health', 'When words failed, a paintbrush said everything I could not.'],
  ['We organized a whole festival — and we are 16', 'Activism', 'No adults, no budget, just a wild idea and a lot of group chats.'],
  ['My identity is not up for debate', 'Identity', 'A raw, honest take on growing up between two worlds.'],
];

const AUTHOR_BIOS = [
  'Maya R. is the 17-year-old founder of BuzzCampus. She writes about politics, power, and why teens deserve a seat at the table.',
  'Leo K. is a 16-year-old writer obsessed with mental health, music, and making people feel less alone.',
  'Amara O. is an 18-year-old culture writer documenting the trends adults discover six months too late.',
  'Jin P. is a 15-year-old opinion columnist who never met a hot take he could not defend.',
  'Sofia M. is a 17-year-old identity writer making space for the stories that do not fit in a box.',
  'Diego T. is a 16-year-old climate correspondent turning eco-anxiety into action.',
  'Noor A. is an 18-year-old activist and community organizer writing from the front lines.',
  'Eli W. is a 15-year-old writer and artist who believes creativity is a form of survival.',
];

const generateBody = (title: string, excerpt: string, category: string): string[] => [
  excerpt,
  `Let me back up. When people hear "${category.toLowerCase()}," they tend to picture something distant — a headline, a hashtag, a problem for someone else to solve. But for a lot of us, it is not abstract at all. It is the thing we think about walking to class, the conversation we have at midnight in a group chat, the feeling we cannot quite put into words until someone finally does.`,
  `That is exactly why I wanted to write this. "${title}" is not a polished take from someone who has it all figured out. It is messy and personal, because that is the only way I know how to tell the truth about it. I have been on both sides — the silence and the speaking up — and I can tell you the second one is scarier and so much better.`,
  `Here is what I have learned: the adults are not coming to save us, and honestly, they do not always need to. We have each other. We have our voices, our phones, our stubbornness, and a generation behind us that refuses to be told to wait our turn. That counts for more than people give us credit for.`,
  `So if you are reading this and you feel even a little bit seen — good. That is the whole point. Send this to the person who needs it. Start the conversation. Write your own version. The future is not something that happens to us; it is something we get to build, loud and out loud, starting right now.`,
  `We don't wait to be heard. And neither should you.`,
];

export const ARTICLES: Article[] = titles.map((t, i) => ({
  id: i + 1,
  title: t[0],
  category: t[1],
  excerpt: t[2],
  body: generateBody(t[0], t[2], t[1]),
  author: ['Maya R.', 'Leo K.', 'Amara O.', 'Jin P.', 'Sofia M.', 'Diego T.', 'Noor A.', 'Eli W.'][i % 8],
  authorAvatar: avatars[i % avatars.length],
  authorBio: AUTHOR_BIOS[i % 8],
  cover: covers[i % covers.length],
  date: `${['May', 'Apr', 'Jun', 'Mar'][i % 4]} ${(i % 27) + 1}, 2026`,
  readTime: `${(i % 5) + 3} min read`,
  featured: i < 3,
}));

export const TEAM: TeamMember[] = [
  { id: 1, name: 'Maya Rivera', role: 'Founder & Editor-in-Chief', bio: 'Started BuzzCampus at 15 because she was sick of being talked over.', photo: avatars[0] },
  { id: 2, name: 'Leo Kim', role: 'Managing Editor', bio: 'Believes every teen has a story worth a front page.', photo: avatars[1] },
  { id: 3, name: 'Amara Okafor', role: 'Culture Lead', bio: 'Documents the trends adults discover six months too late.', photo: avatars[2] },
  { id: 4, name: 'Jin Park', role: 'Opinion Editor', bio: 'Loves a hot take, lives for a good debate.', photo: avatars[3] },
  { id: 5, name: 'Sofia Moretti', role: 'Identity Editor', bio: 'Making space for the stories that do not fit in a box.', photo: avatars[4] },
  { id: 6, name: 'Diego Torres', role: 'Climate Correspondent', bio: 'Turning his eco-anxiety into action, one article at a time.', photo: avatars[5] },
  { id: 7, name: 'Noor Ahmadi', role: 'Community Manager', bio: 'Keeps our global writer crew of 600+ feeling like family.', photo: avatars[6] },
  { id: 8, name: 'Eli Wright', role: 'Design Lead', bio: 'Makes sure BuzzCampus looks as loud as it sounds.', photo: avatars[7] },
];

export const COUNTRIES = ['United States', 'United Kingdom', 'Canada', 'Australia', 'India', 'Nigeria', 'Brazil', 'Germany', 'Japan', 'South Korea', 'Mexico', 'France', 'South Africa', 'Philippines', 'Other'];
